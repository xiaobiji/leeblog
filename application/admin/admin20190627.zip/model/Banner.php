<?php
/**
 * Created by PhpStorm.
 * User: yifeng
 * Date: 2017/11/20
 * Time: 22:30
 */

namespace app\admin\model;


use think\Model;

class Banner extends Model
{

}