<?php
/**
 * Created by PhpStorm.
 * User: yifeng
 * Date: 2017/10/23
 * Time: 12:46
 */

namespace app\admin\model;


use think\Model;

class Member extends Model
{
   //
}