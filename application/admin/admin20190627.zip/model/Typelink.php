<?php

namespace app\admin\model;

use think\Model;

class Typelink extends Model
{
    //
}
