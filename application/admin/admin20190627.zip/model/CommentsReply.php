<?php
/**
 * Created by PhpStorm.
 * User: yifeng
 * Date: 2017/11/2
 * Time: 21:51
 */

namespace app\admin\model;


use think\Model;

class CommentsReply extends Model
{
    protected $table = "lee_Comments_reply"; //这里填写真实的数据库表名
}