<?php
/**
 * Created by PhpStorm.
 * User: yifeng
 * Date: 2017/11/2
 * Time: 21:51
 */

namespace app\admin\model;


use think\Model;

class Comments extends Model
{

}